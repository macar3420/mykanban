mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 8.4.5, for Linux (x86_64)
--
-- Host: mob-barley-db.c34y2w8we6eu.eu-north-1.rds.amazonaws.com    Database: mob_barley
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `boards`
--

DROP TABLE IF EXISTS `boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `boards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `team_id` bigint unsigned DEFAULT NULL,
  `owner_user_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_boards_team` (`team_id`),
  KEY `idx_boards_owner` (`owner_user_id`),
  CONSTRAINT `fk_boards_owner` FOREIGN KEY (`owner_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_boards_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boards`
--

/*!40000 ALTER TABLE `boards` DISABLE KEYS */;
INSERT INTO `boards` VALUES (1,'Default Board',NULL,NULL,'2025-10-14 13:14:00'),(2,'My Board',NULL,1,'2025-10-14 13:24:28'),(3,'My Board',NULL,2,'2025-10-14 13:28:49'),(4,'My Board',NULL,3,'2025-10-14 13:35:08'),(5,'My Board',NULL,4,'2025-10-14 13:50:02'),(6,'My Board',NULL,5,'2025-10-22 11:54:31'),(7,'My Board',NULL,8,'2025-10-22 12:05:49');
/*!40000 ALTER TABLE `boards` ENABLE KEYS */;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` varchar(64) NOT NULL,
  `title` varchar(255) NOT NULL,
  `column_key` enum('todo','inprogress','done') NOT NULL DEFAULT 'todo',
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

/*!40000 ALTER TABLE `items` DISABLE KEYS */;
/*!40000 ALTER TABLE `items` ENABLE KEYS */;

--
-- Table structure for table `reset_tokens`
--

DROP TABLE IF EXISTS `reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reset_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token` char(64) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reset_token` (`token`),
  KEY `idx_rt_user` (`user_id`),
  CONSTRAINT `fk_rt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reset_tokens`
--

/*!40000 ALTER TABLE `reset_tokens` DISABLE KEYS */;
INSERT INTO `reset_tokens` VALUES (1,1,'2e5540da6ffb68ba91132c186f8013aa14fe948dc659e7241377e513d9ba2e63','2025-10-14 15:36:29',NULL,'2025-10-14 14:36:28'),(2,1,'ba1ef609f42cabc52929b1982f69eb12ab1afcabe8c8040c187fcd44c6e98023','2025-10-14 15:36:48',NULL,'2025-10-14 14:36:48'),(3,1,'f8b7bdb1a9c97eb76720cd14a00dc5e38bc0d89becb698a1a34efd4b6a02ec7e','2025-10-14 15:50:14',NULL,'2025-10-14 14:50:14'),(4,1,'ef766fafd9c72a7b7316e623dab1840cdcd34ac1dfca697620e63ad69313a1d0','2025-10-14 15:51:21',NULL,'2025-10-14 14:51:20'),(5,1,'e39718b0d6cfd20be83e876a0f9c2011c9c9ceb71fb09d797dd1ee8a0795b954','2025-10-14 16:04:03',NULL,'2025-10-14 15:04:03'),(6,4,'d09a6c5cdcc0266506e34a9e0f74ddec197db2ff5e43f050af76fb3c4e40b012','2025-10-14 16:06:14',NULL,'2025-10-14 15:06:14'),(7,4,'66f7748be8ea9d968163ae5d76af345ac9bf1fe2501fd990ce8b7b2c5684714b','2025-10-14 16:09:30',NULL,'2025-10-14 15:09:30'),(8,1,'551ca573860a88b405ed333da8c556528300efc098c501f3be72c41d76063c7b','2025-10-14 16:09:58',NULL,'2025-10-14 15:09:58'),(9,1,'9dd4e921b031f42249b50a7965c4e78c24da32f7bb4bba88f8213228d3f32212','2025-10-14 16:11:30',NULL,'2025-10-14 15:11:29'),(10,1,'9f14588d56479f794782cbcef213c2afb775a6ce432b45348a45888fd33afa00','2025-10-14 16:11:31',NULL,'2025-10-14 15:11:30'),(11,1,'390429d22288947efa0b43fbd6991591428ecbd746c9732338327eed69ecd74a','2025-10-14 16:11:32',NULL,'2025-10-14 15:11:31'),(12,4,'fce4cd18f8b795968e733b5981083264e55c105917c9b1bfa2738d0789ad0b94','2025-10-14 16:12:58',NULL,'2025-10-14 15:12:58'),(13,4,'39c99a765fec080835c843376a2c3484b3d941e42780aeebc38663f57a070da6','2025-10-14 16:13:58',NULL,'2025-10-14 15:13:58'),(14,1,'52c7e1e62b3ba929dcbeabdc439410a325eb518a3b19feea5862d0755c09753b','2025-10-14 16:16:29',NULL,'2025-10-14 15:16:29');
/*!40000 ALTER TABLE `reset_tokens` ENABLE KEYS */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `token` char(64) NOT NULL,
  `expires_at` timestamp NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sessions_token` (`token`),
  KEY `idx_sessions_user` (`user_id`),
  CONSTRAINT `fk_sessions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'f644476b486191146b99f3c6f6d01ba3d0c325299a6523a2c6b520cf1de5185e','2025-10-21 16:12:08','2025-10-14 13:24:28'),(7,3,'9261005183899db8b9c60c053a10ae79b6662d7eb0822b72cbbc83803c4a9baf','2025-10-21 16:21:55','2025-10-14 13:35:08'),(8,3,'604397280473ff045de501becc903dfd97eeb1ec3f9f6d9358f84b34b560d30e','2025-10-21 16:22:45','2025-10-14 13:36:02'),(38,5,'5ff49a5f9737bd1a15b1f6bfa50609c23d00ac1348fff92306000c6bf42b9336','2025-10-29 12:14:25','2025-10-22 12:14:29'),(39,1,'8d811446bbd01ab9d1361c7a15c99c4b8bb60233638f40b3e9ebf2b7706d58a4','2025-10-31 08:27:07','2025-10-24 08:27:06'),(40,1,'469b1022ab0cbf7d9a71a67d5ec47dcaa0416a4119962a347defdc56d034c640','2025-11-02 15:21:49','2025-10-26 12:29:13'),(42,5,'158ea7f9974f024c00cf014f83b1944db1a81e72e381e385c6364e84f06cda33','2025-11-04 09:59:15','2025-10-28 09:59:15'),(47,1,'4706c1b7633b2d97c260e63ce57012aaf50e5c9de5ab118601bfe809d9c99bad','2025-11-05 14:51:09','2025-10-29 12:53:35'),(50,1,'009e01ab569f745405875d9da580eb92c5eaf3a626124de1c367e6a54976da8e','2025-11-09 13:54:21','2025-11-02 13:54:21'),(54,5,'18a0e079b0e5b01dd32123b653e998dc34c03f112db52d5c5d2fccc61ba921a0','2025-11-18 10:33:07','2025-11-11 10:33:07'),(55,1,'89b065d64093ad446e7ed8fe6d4ac908eb0ac65a9680f93e6666fb5193fb8ad0','2025-11-18 10:47:37','2025-11-11 10:47:37');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `status` enum('todo','inprogress','done') NOT NULL DEFAULT 'todo',
  `done` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `board_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_done` (`done`),
  KEY `idx_tasks_board` (`board_id`),
  CONSTRAINT `fk_tasks_board` FOREIGN KEY (`board_id`) REFERENCES `boards` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,'hel','todo',1,'2025-10-06 15:35:46','2025-10-14 13:14:00',1),(2,'hello from UI','done',1,'2025-10-06 15:36:49','2025-10-14 13:14:00',1),(3,'HELLOOOO','todo',0,'2025-10-06 17:14:15','2025-10-14 13:14:00',1),(4,'try','done',1,'2025-10-06 17:20:51','2025-10-14 13:14:00',1),(5,'progress','inprogress',0,'2025-10-06 17:20:55','2025-10-14 13:14:00',1),(6,'LAURAAAAAA','todo',0,'2025-10-07 16:15:16','2025-10-14 13:14:00',1),(7,'ACARRRRRRRR','inprogress',0,'2025-10-07 16:15:26','2025-10-14 13:14:00',1),(8,'CLI','inprogress',0,'2025-10-07 20:52:38','2025-10-14 13:14:00',1),(9,'ffbfbf','done',1,'2025-10-07 20:56:38','2025-10-14 13:14:00',1),(12,'damn','inprogress',0,'2025-10-14 08:58:09','2025-10-14 13:14:00',1),(15,'Hello from macar','todo',0,'2025-10-14 13:25:57','2025-10-14 13:25:57',2),(16,'is this working','inprogress',0,'2025-10-14 13:26:16','2025-10-14 13:26:16',2),(17,'done is it?','done',1,'2025-10-14 13:26:21','2025-10-14 13:26:24',2),(18,'hello from laura','todo',0,'2025-10-14 13:28:54','2025-10-14 13:28:54',3),(19,'Hello from mustafa','todo',0,'2025-10-14 13:50:10','2025-10-14 13:50:10',5),(20,'bbgg','inprogress',0,'2025-10-14 13:50:13','2025-10-14 13:50:15',5),(21,'hello','todo',0,'2025-10-22 11:59:21','2025-10-22 12:12:14',6),(22,'hjhjh','inprogress',0,'2025-10-28 13:26:55','2025-10-28 13:26:55',2);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;

--
-- Table structure for table `team_members`
--

DROP TABLE IF EXISTS `team_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_members` (
  `team_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `role` enum('owner','admin','member') NOT NULL DEFAULT 'member',
  `added_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`team_id`,`user_id`),
  KEY `idx_tm_user` (`user_id`),
  CONSTRAINT `fk_tm_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tm_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_members`
--

/*!40000 ALTER TABLE `team_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_members` ENABLE KEYS */;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_teams_owner` (`created_by`),
  CONSTRAINT `fk_teams_owner` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_display_name` (`display_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'mustafa.acar@tuni.fi','$2a$10$mbEJx5kdz/hzteuhF6F9SOmPkmvH/4wyUBssEMM8IrE79Q3pRJZ.y','macar','2025-10-14 13:24:28'),(2,'laurann95@hotmail.com','$2a$10$SjaifroHzz8wA3CyAxzYLuxxrUiNV3hmL/PSlEKb0myAqEwQIhEoq','laura','2025-10-14 13:28:49'),(3,'test@example.com','$2a$10$RxWzbYQguazEYIRPgG44gOxUJBolRaSpJGL/NfDb2hoTBYwb/hrvS','tester','2025-10-14 13:35:08'),(4,'acar.mustafan@gmail.com','$2a$10$FNJwF89er3RrHGe.YBwyUuQm3qMei.g2dtyBQxzM/r0cfQUCEPdii','mustafa','2025-10-14 13:50:02'),(5,'thomas.laranjo@tuni.fi','$2a$10$2JOmofWkLBJB3PJF5.FJj.mD34Ct3TPopWLjAwkOqCppOrxwvemgG','ak47xno','2025-10-22 11:54:31'),(8,'thomas.laranjo841@gmail.com','$2a$10$/gdE7SAyGiohFV7Bw0lnBuEOfBThpmqSznYfuvCo3/8C5u3YxDOGG','thomasl','2025-10-22 12:05:49');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

--
-- Dumping events for database 'mob_barley'
--

--
-- Dumping routines for database 'mob_barley'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-12  9:52:13
